namespace WindowsFormsApp1
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;
    using System.Collections.Generic;
    using System.Data.SqlClient;

    /// <summary>
    /// Summary description for Report3.
    /// </summary>
    public partial class OrgChart : Telerik.Reporting.Report
    {
        public OrgChart()
        {
            InitializeComponent();

            // decrease the detail section height in case the subreport is hiden
            this.detail.Height = this.detail.Height - this.ManagedEmployees.Height;
        }

        static public InstanceReportSource createReportInstance(Telerik.Reporting.Processing.SubReport item)
        {
            // get the data to wich the subreport item is bound
            var subReportItemData = item.DataObject;
            var managedEmployees = (List<Employee>)subReportItemData["ManagedEmployees"];

            if (null != managedEmployees)
            {
                InstanceReportSource rs = new InstanceReportSource();
                // create new instance of the same report
                OrgChart r = new OrgChart();

                // and bind it to the managed employees
                r.DataSource = managedEmployees;

                rs.ReportDocument = r;

                return rs;
            }

            return null;
        }
    }

    #region Report Data
    public class Employees : List<Employee>
    {
        public Employees()
        {
            string connectionString = @"Data Source=(local)\SQLEXPRESS;Initial Catalog=AdventureWorks;Integrated Security=True";
            string sql = "select e.EmployeeID, e.ManagerID, e.Title, c.FirstName, "
                + "c.LastName, e.LoginID from HumanResources.Employee "
                + "e inner join Person.Contact c on e.ContactID = c.ContactID "
                + "order by e.ManagerID";
            List<Employee> employees = new List<Employee>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Employee e = this.Read(reader);
                    employees.Add(e);
                }
            }

            this.InsertAll(employees);
        }

        private Employee Read(SqlDataReader reader)
        {
            int employeeID = reader.GetInt32(0);
            int managerID = reader[1] == System.DBNull.Value ? 0 : (int)reader.GetInt32(1);
            string title = reader.GetString(2);
            string firstName = reader.GetString(3);
            string lastName = reader.GetString(4);
            string loginID = reader.GetString(5);
            return new Employee
            {
                EmployeeID = employeeID
                ,
                ManagerID = managerID
                ,
                Title = title
                ,
                FirstName = firstName
                ,
                LastName = lastName
                ,
                LoginID = loginID
                ,
                ManagedEmployees = new List<Employee>()
            };
        }

        private void InsertAll(List<Employee> employees)
        {
            foreach (Employee e in employees)
            {
                if (this.Count == 0 || e.ManagerID == null)
                {
                    this.Add(e);
                }
                else
                {
                    foreach (Employee manager in employees)
                        if (Insert(manager, e, 2))
                            break;
                }
            }
        }

        private bool Insert(Employee manager, Employee e, int tab)
        {
            if (manager.EmployeeID == e.ManagerID)
            {
                manager.ManagedEmployees.Add(e);
                e.Manager = manager;
                return true;
            }
            else
            {
                foreach (Employee m in manager.ManagedEmployees)
                    if (Insert(m, e, tab))
                        return true;
            }
            return false;
        }
    }

    public class Employee
    {
        public int EmployeeID { get; set; }
        public int? ManagerID { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LoginID { get; set; }
        public List<Employee> ManagedEmployees { get; set; }
        public Employee Manager { get; set; }
        public override string ToString()
        {
            string mask = "{0} {1} {2} {3} {4}";
            return string.Format(mask, ManagerID, EmployeeID, Title, FirstName, LastName);
        }
    }
    #endregion Report Data
}