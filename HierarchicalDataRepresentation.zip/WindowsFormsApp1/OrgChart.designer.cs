namespace WindowsFormsApp1
{
    partial class OrgChart
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Drawing.FormattingRule formattingRule2 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Drawing.FormattingRule formattingRule3 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            this.detail = new Telerik.Reporting.DetailSection();
            this.EmployeeName = new Telerik.Reporting.TextBox();
            this.ManagedEmployees = new Telerik.Reporting.SubReport();
            this.NumberOfManagedEmployees = new Telerik.Reporting.TextBox();
            this.EmployeeTitle = new Telerik.Reporting.TextBox();
            this.objectDataSource1 = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // detail
            // 
            this.detail.Height = new Telerik.Reporting.Drawing.Unit(0.60000020265579224D, Telerik.Reporting.Drawing.UnitType.Inch);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.EmployeeName,
            this.ManagedEmployees,
            this.NumberOfManagedEmployees,
            this.EmployeeTitle});
            this.detail.Name = "detail";
            this.detail.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.detail.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.detail.Style.BorderWidth.Left = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Pixel);
            // 
            // EmployeeName
            // 
            formattingRule1.Filters.AddRange(new Telerik.Reporting.Filter[] {
            new Telerik.Reporting.Filter("= Fields.ManagedEmployees.Count", Telerik.Reporting.FilterOperator.GreaterThan, "=0")});
            formattingRule1.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.EmployeeName.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
            this.EmployeeName.Location = new Telerik.Reporting.Drawing.PointU(new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(3.9378803194267675E-05D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.Size = new Telerik.Reporting.Drawing.SizeU(new Telerik.Reporting.Drawing.Unit(3.0999212265014648D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.20000004768371582D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.EmployeeName.Value = "{Fields.FirstName} {Fields.LastName}";
            // 
            // ManagedEmployees
            // 
            this.ManagedEmployees.Bindings.Add(new Telerik.Reporting.Binding("ReportSource", "= createReportInstance(ReportItem)"));
            formattingRule2.Filters.AddRange(new Telerik.Reporting.Filter[] {
            new Telerik.Reporting.Filter("=Fields.ManagedEmployees.Count", Telerik.Reporting.FilterOperator.Equal, "=0")});
            formattingRule2.Style.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            formattingRule2.Style.BackgroundImage.MimeType = "";
            formattingRule2.Style.BackgroundImage.Repeat = Telerik.Reporting.Drawing.BackgroundRepeat.Repeat;
            formattingRule2.Style.BorderColor.Bottom = System.Drawing.Color.Black;
            formattingRule2.Style.BorderColor.Default = System.Drawing.Color.Black;
            formattingRule2.Style.BorderColor.Left = System.Drawing.Color.Black;
            formattingRule2.Style.BorderColor.Right = System.Drawing.Color.Black;
            formattingRule2.Style.BorderColor.Top = System.Drawing.Color.Black;
            formattingRule2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.None;
            formattingRule2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            formattingRule2.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            formattingRule2.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            formattingRule2.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            formattingRule2.Style.BorderWidth.Bottom = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.BorderWidth.Default = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.BorderWidth.Left = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.BorderWidth.Right = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.BorderWidth.Top = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.Color = System.Drawing.Color.Black;
            formattingRule2.Style.Font.Bold = false;
            formattingRule2.Style.Font.Italic = false;
            formattingRule2.Style.Font.Name = "Arial";
            formattingRule2.Style.Font.Size = new Telerik.Reporting.Drawing.Unit(10D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.Font.Strikeout = false;
            formattingRule2.Style.Font.Underline = false;
            formattingRule2.Style.LineStyle = Telerik.Reporting.Drawing.LineStyle.Solid;
            formattingRule2.Style.LineWidth = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Point);
            formattingRule2.Style.Padding.Bottom = new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch);
            formattingRule2.Style.Padding.Left = new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch);
            formattingRule2.Style.Padding.Right = new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch);
            formattingRule2.Style.Padding.Top = new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch);
            formattingRule2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            formattingRule2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            formattingRule2.Style.Visible = false;
            this.ManagedEmployees.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule2});
            this.ManagedEmployees.Location = new Telerik.Reporting.Drawing.PointU(new Telerik.Reporting.Drawing.Unit(0.30000004172325134D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.40000009536743164D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.ManagedEmployees.Name = "ManagedEmployees";
            this.ManagedEmployees.Size = new Telerik.Reporting.Drawing.SizeU(new Telerik.Reporting.Drawing.Unit(3.2000000476837158D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.20000012218952179D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.ManagedEmployees.Style.BackgroundColor = System.Drawing.Color.Empty;
            this.ManagedEmployees.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ManagedEmployees.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.ManagedEmployees.Style.BorderWidth.Default = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Pixel);
            // 
            // NumberOfManagedEmployees
            // 
            this.NumberOfManagedEmployees.Location = new Telerik.Reporting.Drawing.PointU(new Telerik.Reporting.Drawing.Unit(3.1000001430511475D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.NumberOfManagedEmployees.Name = "NumberOfManagedEmployees";
            this.NumberOfManagedEmployees.Size = new Telerik.Reporting.Drawing.SizeU(new Telerik.Reporting.Drawing.Unit(0.39996084570884705D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.19999997317790985D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.NumberOfManagedEmployees.Value = "({Fields.ManagedEmployees.Count})";
            // 
            // EmployeeTitle
            // 
            formattingRule3.Filters.AddRange(new Telerik.Reporting.Filter[] {
            new Telerik.Reporting.Filter("= Fields.ManagedEmployees.Count", Telerik.Reporting.FilterOperator.GreaterThan, "=0")});
            formattingRule3.Style.BackgroundColor = System.Drawing.Color.Silver;
            this.EmployeeTitle.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule3});
            this.EmployeeTitle.Location = new Telerik.Reporting.Drawing.PointU(new Telerik.Reporting.Drawing.Unit(3.9378803194267675E-05D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.20000004768371582D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.EmployeeTitle.Name = "EmployeeTitle";
            this.EmployeeTitle.Size = new Telerik.Reporting.Drawing.SizeU(new Telerik.Reporting.Drawing.Unit(3.0998818874359131D, Telerik.Reporting.Drawing.UnitType.Inch), new Telerik.Reporting.Drawing.Unit(0.20000004768371582D, Telerik.Reporting.Drawing.UnitType.Inch));
            this.EmployeeTitle.Style.Font.Italic = true;
            this.EmployeeTitle.Style.Font.Size = new Telerik.Reporting.Drawing.Unit(8D, Telerik.Reporting.Drawing.UnitType.Point);
            this.EmployeeTitle.Value = "= Fields.Title";
            // 
            // objectDataSource1
            // 
            this.objectDataSource1.DataSource = typeof(WindowsFormsApp1.Employees);
            this.objectDataSource1.Name = "objectDataSource1";
            // 
            // OrgChart
            // 
            this.DataSource = this.objectDataSource1;
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.detail});
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins.Bottom = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Inch);
            this.PageSettings.Margins.Left = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Inch);
            this.PageSettings.Margins.Right = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Inch);
            this.PageSettings.Margins.Top = new Telerik.Reporting.Drawing.Unit(1D, Telerik.Reporting.Drawing.UnitType.Inch);
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Letter;
            reportParameter1.Name = "ManagerID";
            reportParameter1.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter1.Value = "=0";
            this.ReportParameters.Add(reportParameter1);
            this.Style.BackgroundColor = System.Drawing.Color.White;
            this.Width = new Telerik.Reporting.Drawing.Unit(3.5D, Telerik.Reporting.Drawing.UnitType.Inch);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.ObjectDataSource objectDataSource1;
        private Telerik.Reporting.TextBox EmployeeName;
        private Telerik.Reporting.SubReport ManagedEmployees;
        private Telerik.Reporting.TextBox NumberOfManagedEmployees;
        private Telerik.Reporting.TextBox EmployeeTitle;
    }
}